tempListWrite = []

tempFile = open('redditScrapedC.txt', "r")
for line in tempFile:
    tempListWrite.append(line)
tempFile.close()

startingPoint = 0

print(len(tempListWrite))

while True:
    tempFlag = True
    for i in range(startingPoint, len(tempListWrite)):
        print(i)
        tempString = tempListWrite[i]
        print(tempString)
        if tempString[-2] != "0" and tempString[-2] != "1" and tempString[-2] != "2" and tempString[-2] != "3" and tempString[-2] != "4" and tempString[-2] != "5" and tempString[-2] != "6" and tempString[-2] != "7" and tempString[-2] != "8" and tempString[-2] != "9":
            tempListWrite.pop(i)
            startingPoint = i - 2
            tempFlag = False
            break
    if tempFlag == True:
        break
    
f = open('redditScrapedC.txt', "w")
for i in range (len(tempListWrite)):
    try:
        f.write(tempListWrite[i])
    except UnicodeEncodeError:
        continue
f.close()