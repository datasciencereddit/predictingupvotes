#Features: title score, time, weekday, number.of.comments
#Label: upvotes OR upvote ratio
#Features are our predictors and we can have multiple.
#We can only have 1 label at a time. It is what we are trying to predict.

install.packages("neuralnet")

library(neuralnet)

norm <-function(x) { (x -min(x))/(max(x)-min(x))   }
denorm <- function(x, max, min){ x * (max - min) + min }

relevantCol <- redditScraped[,c(3,8,11,12, 5)]

max<- as.data.frame(lapply(relevantCol, max))
max <- max[,c(1,2,3,4,5,5)]
max <- rename(max, predicted.upvotes = upvotes.1)
max <- rbind(max, max[rep(1,999),])

min <- as.data.frame(lapply(relevantCol, min))
min <- min[,c(1,2,3,4,5,5)]
min <- rename(min, predicted.upvotes = upvotes.1)
min <- rbind(min, min[rep(1,999),])

data_norm <- as.data.frame(lapply(relevantCol, norm))
#The format for the first argument is Label~Feature1+Feature2+...
#all instances of cleanData should be changed to whatever you named your dataset
#The other arguments should not be changed
nn = neuralnet(upvotes~title.score+number.comments+time+weekday,
               data = data_norm, hidden=2, act.fct = "logistic", 
               linear.output = FALSE)

plot(nn)

#This creates the testing data we will enter into our neural net.
#Currently it is taking a random sample of 1000 entries
testSet <- data_norm[sample(nrow(data_norm), 1000),]



prediction <- compute(nn, testSet[,-5])

#prediction$net.result will contain our NN's predictions for the test data
#Compare to the actual upvote/upvote ratio for the test set
testSet[,6] <- prediction$net.result
testSet <- rename(testSet, predicted.upvotes = 'V6')

testSet <- as.data.frame(mapply(denorm, testSet[,c(1,2,3,4,5,6)], max, min))

#testSet <- testSet[,c('id','title','title.score','author.name','upvotes',
  #                                'predicted.upvotes', 'upvote.ratio','number.comments',
   #                               'subreddit', 'time.of.upload','time','weekday')]

temp <- addup(testSet[,5], testSet[,6])
