#normalization function
norm <-function(x) { (x -min(x))/(max(x)-min(x))   }

#accuracy function
addup <- function(x, y){sum(y,-x)}
acc <- function(x) { sqrt((X^2)/n)}

library(class)

ran <- sample(1:nrow(redditScraped), 0.9 * nrow(redditScraped))

#Ensure that your columns are appropriately in numeric before normalization
data_norm <- as.data.frame(lapply(redditScraped[,c(3,7,10,11, 5)], norm))

fTrain <- data_norm[ran,]
fTest <- data_norm[-ran,]
labelTrain <- data_norm[ran, 5]
labelTest <- data_norm[-ran, 5]

max <- rbind(max, max[rep(1,13654),])
min <- rbind(min, min[rep(1,13654),])


knnPred <- knn(fTrain, fTest, cl=labelTrain, k=13)
knnPred <- unlist(knnPred)
knnPred <- as.vector(knnPred)
knnPred <- as.numeric(knnPred)

temp <- addup(knnPred, labelTest)
temp <- (temp^2)/(nrow(redditScraped)*0.1)
temp <- sqrt(temp)

