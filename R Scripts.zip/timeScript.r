library(chron)
library(dplyr)

#converts date/time into chron
redditScraped[,8] <- as.chron(redditScraped[,8])
chronList <- chron::chron(substr(redditScraped$time.of.upload, 1, 10), substr(redditScraped$time.of.upload, 12, 19), format = c(dates = "y-m-d", times = "h:m:s"))
redditScraped$time.of.upload <- chronList
remove(chronList)

#creates and formats the weekday and time columns
redditScraped[,10] <- weekdays(redditScraped$time.of.upload)
redditScraped[,11] <- hours(redditScraped$time.of.upload) + (minutes(redditScraped$time.of.upload)/60)
redditScraped$V11 <- round(redditScraped$V11, 2)
redditScraped <- rename(redditScraped, weekday = V10, time = V11)
redditScraped$weekday <- as.character(redditScraped$weekday)



#refactors the weekday column into 1-7 for Sunday-Saturday
count <- 0
for(day in redditScraped$weekday){
  count <- count + 1
  if(day == 'Sun'){
    redditScraped[count, 'weekday'] = 1
  }
  else if(day == 'Mon'){
    redditScraped[count, 'weekday'] = 2
  }
  else if(day == 'Tue'){
    redditScraped[count, 'weekday'] = 3
  }
  else if(day == 'Wed'){
    redditScraped[count, 'weekday'] = 4
  }
  else if(day == 'Thu'){
    redditScraped[count, 'weekday'] = 5
  }
  else if(day == 'Fri'){
    redditScraped[count, 'weekday'] = 6
  }
  else if(day == 'Sat'){
    redditScraped[count, 'weekday'] = 7
  }
}
remove(count)
redditScraped$weekday <- as.numeric(redditScraped$weekday)

#rearranges columns into a more readable order
#Note: this assumes you named the title score column title.score
#if not, use the rename function
#redditScraped <- rename(redditScraped, title.score = 'CURRENT_NAME')
redditScraped <- redditScraped[,c('id','title','title.score','author.name','upvotes',
                                  'upvote.ratio','number.comments','subreddit',
                                  'time.of.upload','time','weekday')]
